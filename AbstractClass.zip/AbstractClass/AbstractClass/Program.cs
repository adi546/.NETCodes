﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractClass
{
    /*
     Shapes - Rectangle, Circle, Triangle
     find Area

    Entities - Rectangle, Circle, Triangle

    Rectangle : Height and Width

    Circle : Radius and PI 

    Triangle : Width and Height 
     
     
     
     
     */

    public abstract class Shape
    {

        public double Height;

        public double Width;

        public double Radius;

        public const float PI = 3.14f;


        public abstract void Area();  // Abstract Method
    }

    public class Rectangle : Shape
    {
        public Rectangle(double Height, double Width)
        {
            this.Height = Height;
            this.Width = Width;
        }

        public override void Area()   // Override keleli method
        {
            Console.WriteLine($"Area of rectangle is {Height * Width}");
        }

        public class Circle : Shape
        {
            public Circle(double Radius)
            {
                this.Radius = Radius;
            }

            public override void Area()
            {
                Console.WriteLine($"Area of circle is {PI * Radius * Radius}");
            }

        }

        public class Triangle : Shape
        {
            public Triangle(double Height, double Width)
            {
                this.Height = Height;
                this.Width = Width;
            }

            public override void Area()
            {
                Console.WriteLine($"Area of triangle is {(Height * Width) / 2}");
            }
        }

        public class Program
        {
            static void Main(string[] args)
            {
                Rectangle rect = new Rectangle(10, 5);
                rect.Area();

                Circle c = new Circle(5);
                c.Area();

                Triangle triangle = new Triangle(10, 5);
                triangle.Area();

                Console.ReadKey();
            }
        }
    }
}