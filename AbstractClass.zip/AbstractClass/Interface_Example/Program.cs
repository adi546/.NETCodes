﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Interface_Example
{
    /*
     delivery company

     different kinds of delivery methods:
     1. Bike Delivery
     2. Car Delivery
     3. Drone Delivery 

    - different ways of delivering packing but they all share 
       same functionality : they can deliver a package and provide
       an estimated delivery time
    
     
     */

    public interface IDelivery
    {  // Common functionality is defined
        void DeliverPackage(string packageDetails);

        int GetEstimatedTime(int distance);
    }

    public class BikeDelivery : IDelivery
    {
        public void DeliverPackage(string packageDetails)
        {
            Console.WriteLine($"Bike Delivery : Delivering {packageDetails} by bike");
        }

        public int GetEstimatedTime(int distance)
        {
            return distance * 2;  // 2 minutes per km 
        }
    }

    public class CarDelivery : IDelivery
    {
        public void DeliverPackage(string packageDetails)
        {
            Console.WriteLine($"Car Delivery : Delivering {packageDetails} by car");
        }

        public int GetEstimatedTime(int distance)
        {
            return distance; // 1 minute per km
        }
    }

    public class DroneDelivery : IDelivery
    {
        public void DeliverPackage(string packageDetails)
        {
            Console.WriteLine($"Drone Delivery : Delivering {packageDetails} by drone");
        }

        public int GetEstimatedTime(int distance)
        {
            return distance / 2; // 30 seconds per km
        }
    }
    public class Program
    {
        static void Main(string[] args)
        {
            string package1 = "Electronics";

            string package2 = "Clothes";

            int distance = 10;

            // Bike Delivery
            IDelivery bikeDelivery = new BikeDelivery();
            bikeDelivery.DeliverPackage(package1);

            Console.WriteLine($"Estimated time : {bikeDelivery.GetEstimatedTime(distance)} minutes");

            Console.WriteLine();

            // Car Delivery
            IDelivery carDelivery = new CarDelivery();
            carDelivery.DeliverPackage(package2);

            Console.WriteLine($"Estimated time : {carDelivery.GetEstimatedTime(distance)} minutes");

            Console.WriteLine();

            // Drone Delivery

            IDelivery droneDelivery = new DroneDelivery();
            droneDelivery.DeliverPackage(package1);

            Console.WriteLine($"Estimated time : {droneDelivery.GetEstimatedTime(distance)} minutes");

        }
    }
}
