﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rule3
{
    /*
     Rule 3 : We can initialize a Parent class variable by using the child class instance 
     to make it a reference variable so that the reference will be consuming memory of the child
     class instance. 
     
     (Reference is a pointer to an instance that does not have any memory allocation.)
   
     */
    public class Class1
    {
        public Class1()  // Parent Class Constructor 
        {
            Console.WriteLine("Constructor of class 1 is called");
        }

        public void Method1()
        {
            Console.WriteLine("Method 1 is called");
        }

        public void Method2()
        {
            Console.WriteLine("Method 2 is called");
        }


    }

    public class Class2 : Class1
    {
        public Class2()  // Child Class Constructor
        {
            Console.WriteLine("Constructor of class 2 is called ");
        }

        public void Method3()
        {
            Console.WriteLine("Method 3 is called");
        }
    }
    public class Program
    {
        static void Main(string[] args)
        {
            Class1 p;  // intialize a parent class variable

            Class2 obj1 = new Class2();  // child instance 

            p = obj1; // instance is assigned to the parent class variable

            p.Method1();

            p.Method2();

           
            
        }
    }
}
