﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rule2
{
    /*
     Rule 2 : In Inheritance, the child class can access parent class members, but the 
     parent class can never access any members that are purely defined in the child
     class.
     */
    public class Class1
    {
        public Class1()  // Parent Class Constructor 
        {
            Console.WriteLine("Constructor of class 1 is called");
        }

        public void Method1()
        {
            Console.WriteLine("Method 1 is called");
        }

        public void Method2()
        {
            Console.WriteLine("Method 2 is called");
        }


    }

    public class Class2 : Class1
    {
        public Class2()  // Child Class Constructor
        {
            Console.WriteLine("Constructor of class 2 is called ");
        }

        public void Method3()
        {
            Console.WriteLine("Method 3 is called");
        }
    }
    public class Program
    {
        static void Main(string[] args)
        {
            Class1 obj1 = new Class1();  // Parent class object

            obj1.Method1();
            obj1.Method2();
            obj1.Method3();  // Cannot be accessed by parent
        }
    }
}
