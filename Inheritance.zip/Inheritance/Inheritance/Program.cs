﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inheritance
{
    /* Rule 1 : In C#, the parent classes constructor must be accessible to child class, otherwise
     * the inheritance would not be possible because when we create child class object, first it 
     * goes and call the parent constructor, so that parent class variable will be initialized 
     * and we can consume under child class (if constructor is parameterless).

      Parent class should be initialize in order to get consumed by child class.
     */
    public class Class1
    {
        public Class1()  // Parent Class Constructor 
        {
            Console.WriteLine("Constructor of class 1 is called");
        }

        public void Method1()
        {
            Console.WriteLine("Method 1 is called");
        }

        public void Method2()
        {
            Console.WriteLine("Method 2 is called");
        }


    }

    public class Class2 : Class1
    {
        public Class2()  // Child Class Constructor
        {
            Console.WriteLine("Constructor of class 2 is called ");
        }

        public void Method3()
        {
            Console.WriteLine("Method 3 is called");
        }
    }
    public class Program
    {
        static void Main(string[] args)
        {
            Class2 obj1 = new Class2();  // Child class object

            obj1.Method1();
            obj1.Method2();
            obj1.Method3();
        }
    }
}
